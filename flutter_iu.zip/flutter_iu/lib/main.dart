import 'package:flutter/material.dart';
import 'screen_one.dart';
import 'screen_two.dart';
import 'screen_three.dart';
import 'screen_four.dart';
import 'screen_five.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'CalcuGrades',
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home Screen')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navigate to ScreenOne using Navigator.push
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ScreenOne()),
                );
              },
              child: const Text('Screen 1'),
            ),
            const SizedBox(height: 20), // Add some spacing between buttons
            ElevatedButton(
              onPressed: () {
                // Navigate to ScreenTwo using Navigator.push
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ScreenTwo()),
                );
              },
              child: const Text('Screen 2'),
            ),
            const SizedBox(height: 20), // Add some spacing between buttons
            ElevatedButton(
              onPressed: () {
                // Navigate to ScreenThree using Navigator.push
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ScreenThree()),
                );
              },
              child: const Text('Screen 3'),
            ),
            const SizedBox(height: 20), // Add some spacing between buttons
            ElevatedButton(
              onPressed: () {
                // Navigate to ScreenFour using Navigator.push
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ScreenFour()),
                );
              },
              child: const Text('Screen 4'),
            ),
            const SizedBox(height: 20), // Add some spacing between buttons
            ElevatedButton(
              onPressed: () {
                // Navigate to ScreenFive using Navigator.push
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ScreenFive()),
                );
              },
              child: const Text('Screen 5'),
            ),
          ],
        ),
      ),
    );
  }
}
