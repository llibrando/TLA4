package com.example.flutter_iu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
